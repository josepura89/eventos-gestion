from django.db import models
from django.utils import timezone
from django.urls import reverse
from .forms import DateForm


# Create your models here.


class Producto(models.Model):
    id_productos = models.AutoField(primary_key=True, unique=True)
    codigobarra = models.CharField(max_length=40, unique=True, help_text="Ingrese Codigos de Barra")
    descripcion = models.CharField(max_length=150, help_text="Ingrese Descripcion del Producto")
    precioventa = models.DecimalField(max_digits=8, decimal_places=2, help_text="Precio para venta")
    preciocompra = models.DecimalField(max_digits=8, decimal_places=2, help_text="Precio para compra")
    imgprod = models.FileField()

    # Metadata
    class Meta:
        db_table = 'producto'


class CuentasCorriente(models.Model):
    id_ctacorr = models.AutoField(primary_key=True)
    apellido = models.CharField(max_length=45, help_text="Apellido")
    nombre = models.CharField(max_length=45, help_text="Nombre")
    telefono = models.CharField(max_length=30, help_text="Telefono")
    totaldeuda = models.DecimalField(max_digits=8, decimal_places=2, help_text="Deuda")
    modooper = models.SmallIntegerField()
    fechahora = models.DateTimeField(auto_now_add=True, blank=True)
    monto = models.DecimalField(max_digits=8, decimal_places=2, help_text="Metodo")

    # Metadata
    class Meta:
        db_table = 'cuentacorriente'

    # Metodos
    def get_absolute_url(self):
        return reverse('model-detail-view', args=[str(self.id_ctacorr)])


class Movimiento(models.Model):
    id_mov = models.AutoField(primary_key=True)
    total = models.IntegerField()
    modostock = models.SmallIntegerField()
    modoventas = models.SmallIntegerField()
    fechahora = models.DateTimeField(auto_now_add=True, blank=True)
    cantidad = models.IntegerField()
    importe = models.DecimalField(max_digits=8, decimal_places=2)
    productos_id_productos = models.ForeignKey('Producto', models.DO_NOTHING, db_column='producto_id_productos')
    cajas_id_caja = models.ForeignKey('Caja', models.DO_NOTHING, db_column='caja_id_caja')

    # Metadata
    class Meta:
        db_table = 'movimiento'

    # Metodos
    def get_absolute_url(self):
        return reverse('model-detail-view', args=[str(self.id_mov)])


class Comprobante(models.Model):
    id_comprob = models.AutoField(primary_key=True)
    modocomp = models.SmallIntegerField()
    fechahora = models.DateTimeField(auto_now_add=True, blank=True)
    cantidad = models.IntegerField()
    movimientos_id_mov = models.ForeignKey('Movimiento', models.DO_NOTHING,
                                           db_column='movimiento_id_movimientos')
    cuentascorrientes_id_ctacorr = models.ForeignKey('CuentasCorriente', models.DO_NOTHING,
                                                     db_column='cuentascorriente_id_ctacorr', default=0)

    # Metadata
    class Meta:
        db_table = 'comprobante'

        # Metodos
    def get_absolute_url(self):
        return reverse('model-detail-view', args=[str(self.id_comprob)])


class Empleado(models.Model):
    dni_emp = models.IntegerField(primary_key=True, unique=True, default=00000000, help_text="Nro de Documento")
    apellido = models.CharField(max_length=45, help_text="Apellido")
    nombre = models.CharField(max_length=45, help_text="Nombre")
    telefono = models.CharField(max_length=30, help_text="Telefono")
    domicilio = models.CharField(max_length=45, help_text="Domicilio")
    puesto = models.CharField(max_length=45, blank=True, null=True, help_text="Puesto")
    imgemp = models.FileField()
    nivelacceso = models.CharField(max_length=45, blank=True, null=True, help_text="Nivel de Acceso")

    # Metadata
    class Meta:
        db_table = 'empleado'

    # Metodos
    def get_absolute_url(self):
        return reverse('model-detail-view', args=[str(self.dni_emp)])


class Caja(models.Model):
    id_caja = models.AutoField(primary_key=True)
    descripcion = models.CharField(max_length=45, help_text="Ingrese Descripcion")
    empleados_dni_emp = models.ForeignKey('Empleado', models.DO_NOTHING, default=00000000,
                                          db_column='empleados_dni_emp')

    # Metadata
    class Meta:
        db_table = 'caja'

    # Metodos
    def get_absolute_url(self):
        return reverse('model-detail-view', args=[str(self.id_caja)])
