from django.shortcuts import render, redirect
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from .models import CuentasCorriente, Caja, Empleado, Comprobante, Producto, Movimiento

from django.urls import reverse
from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin

# Create your views here.

#Empleados

class EmpleadoListado(ListView):
    model = Empleado

class EmpleadoCrear(SuccessMessageMixin, CreateView):
    model = Empleado
    form = Empleado
    fields = "__all__"
    success_message = 'Empleado Creado Correctamente'

    def get_success_url(self):
        return  reverse('leer')

class EmpleadoDetalle(DeleteView):
    model = Empleado

class EmpleadoActualizar(SuccessMessageMixin, UpdateView):
    model = Empleado
    form = Empleado
    fields = "__all__"
    success_message = 'Empleado Actualizado Correctamente'

    def get_success_url(self):
        return reverse('leer')

class EmpleadoEliminar(SuccessMessageMixin, DeleteView):
    model = Empleado
    form = Empleado
    slug_field = "__all__"

    def get_success_url(self):
        success_message = 'Empleado eliminado Correctamente'
        messages.success(self.request, (success_message))
        return reverse('leer')

# Cajas

class CajaListado(ListView):
    model = Caja

class CajaCrear(SuccessMessageMixin, CreateView):
    model = Caja
    form = Caja
    fields = "__all__"
    success_message = 'Caja Creado Correctamente'

    def get_success_url(self):
        return  reverse('leer')

class CajaDetalle(DeleteView):
    model = Caja

class CajaActualizar(SuccessMessageMixin, UpdateView):
    model = Caja
    form = Caja
    fields = "__all__"
    success_message = 'Caja Actualizado Correctamente'

    def get_success_url(self):
        return reverse('leer')

class CajaEliminar(SuccessMessageMixin, DeleteView):
    model = Caja
    form = Caja
    slug_field = "__all__"

    def get_success_url(self):
        success_message = 'Caja eliminado Correctamente'
        messages.success(self.request, (success_message))
        return reverse('leer')

# Producto

class ProductoListado(ListView):
    model = Producto

class ProductoCrear(SuccessMessageMixin, CreateView):
    model = Producto
    form = Producto
    fields = "__all__"
    success_message = 'Producto Creado Correctamente'

    def get_success_url(self):
        return  reverse('leer')

class ProductoDetalle(DeleteView):
    model = Producto

class ProductoActualizar(SuccessMessageMixin, UpdateView):
    model = Producto
    form = Producto
    fields = "__all__"
    success_message = 'Producto Actualizado Correctamente'

    def get_success_url(self):
        return reverse('leer')

class ProductoEliminar(SuccessMessageMixin, DeleteView):
    model = Producto
    form = Producto
    slug_field = "__all__"

    def get_success_url(self):
        success_message = 'Producto eliminado Correctamente'
        messages.success(self.request, (success_message))
        return reverse('leer')
    
# CuentasCorriente

class CuentasCorrienteListado(ListView):
    model = CuentasCorriente

class CuentasCorrienteCrear(SuccessMessageMixin, CreateView):
    model = CuentasCorriente
    form = CuentasCorriente
    fields = "__all__"
    success_message = 'CuentasCorriente Creado Correctamente'

    def get_success_url(self):
        return  reverse('leer')

class CuentasCorrienteDetalle(DeleteView):
    model = CuentasCorriente

class CuentasCorrienteActualizar(SuccessMessageMixin, UpdateView):
    model = CuentasCorriente
    form = CuentasCorriente
    fields = "__all__"
    success_message = 'CuentasCorriente Actualizado Correctamente'

    def get_success_url(self):
        return reverse('leer')

class CuentasCorrienteEliminar(SuccessMessageMixin, DeleteView):
    model = CuentasCorriente
    form = CuentasCorriente
    slug_field = "__all__"

    def get_success_url(self):
        success_message = 'CuentaCorriente eliminado Correctamente'
        messages.success(self.request, (success_message))
        return reverse('leer')


# Movimientos

class MovimientosListado(ListView):
    model = Movimiento

class MovimientosCrear(SuccessMessageMixin, CreateView):
    model = Movimiento
    form = Movimiento
    fields = "__all__"
    success_message = 'Movimientos Creado Correctamente'

    def get_success_url(self):
        return  reverse('leer')

class MovimientosDetalle(DeleteView):
    model = Movimiento

class MovimientosActualizar(SuccessMessageMixin, UpdateView):
    model = Movimiento
    form = Movimiento
    fields = "__all__"
    success_message = 'Movimientos Actualizado Correctamente'

    def get_success_url(self):
        return reverse('leer')

class MovimientosEliminar(SuccessMessageMixin, DeleteView):
    model = Movimiento
    form = Movimiento
    slug_field = "__all__"

    def get_success_url(self):
        success_message = 'Movimiento eliminado Correctamente'
        messages.success(self.request, (success_message))
        return reverse('leer')

#Comprobantes

class ComprobantesListado(ListView):
    model = Comprobante

class ComprobantesCrear(SuccessMessageMixin, CreateView):
    model = Comprobante
    form = Comprobante
    fields = "__all__"
    success_message = 'Comprobantes Creado Correctamente'

    def get_success_url(self):
        return  reverse('leer')

class ComprobantesDetalle(DeleteView):
    model = Comprobante

class ComprobantesActualizar(SuccessMessageMixin, UpdateView):
    model = Comprobante
    form = Comprobante
    fields = "__all__"
    success_message = 'Comprobantes Actualizado Correctamente'

    def get_success_url(self):
        return reverse('leer')

class ComprobantesEliminar(SuccessMessageMixin, DeleteView):
    model = Comprobante
    form = Comprobante
    slug_field = "__all__"

    def get_success_url(self):
        success_message = 'Comprobante eliminado Correctamente'
        messages.success(self.request, (success_message))
        return reverse('leer')