from django.apps import AppConfig


class GeventosConfig(AppConfig):
    name = 'geventos'
