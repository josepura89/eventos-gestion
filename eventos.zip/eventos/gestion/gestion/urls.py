"""eventos URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
# from django.views.generic import TemplateView
from geventos.views import EmpleadoActualizar, EmpleadoCrear, EmpleadoDetalle, EmpleadoEliminar, EmpleadoListado, CajaActualizar, CajaListado, CajaDetalle, CajaEliminar, CajaCrear, ProductoActualizar, ProductoListado, ProductoDetalle, ProductoEliminar, ProductoCrear, CuentasCorrienteActualizar, CuentasCorrienteListado, CuentasCorrienteDetalle, CuentasCorrienteEliminar, CuentasCorrienteCrear, MovimientosActualizar, MovimientosCrear, MovimientosDetalle, MovimientosEliminar, MovimientosListado, ComprobantesActualizar, ComprobantesCrear, ComprobantesDetalle, ComprobantesEliminar, ComprobantesListado


# from empleado.views import EmpleadoList

from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),

    #Empleados
    path('empleado/', EmpleadoListado.as_view(template_name="empleado/index.html"), name='leer'),
    path('empleado/detalle/<int:pk>', EmpleadoDetalle.as_view(template_name="empleado/detalles.html"), name='detalles'),
    path('empleado/crear', EmpleadoCrear.as_view(template_name="empleado/crear.html"), name='crear'),
    path('empleado/editar/<int:pk>', EmpleadoActualizar.as_view(template_name="empleado/actualizar.html"),
         name='actualizar'),
    path('empleado/eliminar/<int:pk>', EmpleadoEliminar.as_view(), name='eliminar'),

    #Cajas

    path('caja/', CajaListado.as_view(template_name="caja/index.html"), name='leer'),
    path('caja/detalle/<int:pk>', CajaDetalle.as_view(template_name="caja/detalles.html"), name='detalles'),
    path('caja/crear', CajaCrear.as_view(template_name="caja/crear.html"), name='crear'),
    path('caja/editar/<int:pk>', CajaActualizar.as_view(template_name="caja/actualizar.html"),
         name='actualizar'),
    path('caja/eliminar/<int:pk>', CajaEliminar.as_view(), name='eliminar'),


    #Productos

    path('producto/', ProductoListado.as_view(template_name="producto/index.html"), name='leer'),
    path('producto/detalle/<int:pk>', ProductoDetalle.as_view(template_name="producto/detalles.html"), name='detalles'),
    path('producto/crear', ProductoCrear.as_view(template_name="producto/crear.html"), name='crear'),
    path('producto/editar/<int:pk>', ProductoActualizar.as_view(template_name="producto/actualizar.html"),
         name='actualizar'),
    path('producto/eliminar/<int:pk>', ProductoEliminar.as_view(), name='eliminar'),
    
    #CuentaCorriente
    
    path('cuentascorrientes/', CuentasCorrienteListado.as_view(template_name="cuentascorrientes/index.html"), name='leer'),
    path('cuentascorrientes/detalle/<int:pk>', CuentasCorrienteDetalle.as_view(template_name="cuentascorrientes/detalles.html"), name='detalles'),
    path('cuentascorrientes/crear', CuentasCorrienteCrear.as_view(template_name="cuentascorrientes/crear.html"), name='crear'),
    path('cuentascorrientes/editar/<int:pk>', CuentasCorrienteActualizar.as_view(template_name="cuentascorrientes/actualizar.html"),
         name='actualizar'),
    path('cuentascorrientes/eliminar/<int:pk>', CuentasCorrienteEliminar.as_view(), name='eliminar'),

    #Movimientos
    path('movimientos/', MovimientosListado.as_view(template_name="movimientos/index.html"), name='leer'),
    path('movimientos/detalle/<int:pk>', MovimientosDetalle.as_view(template_name="movimientos/detalles.html"), name='detalles'),
    path('movimientos/crear', MovimientosCrear.as_view(template_name="movimientos/crear.html"), name='crear'),
    path('movimientos/editar/<int:pk>', MovimientosActualizar.as_view(template_name="movimientos/actualizar.html"),
         name='actualizar'),
    path('movimientos/eliminar/<int:pk>', MovimientosEliminar.as_view(), name='eliminar'),

    #Comprobantes

    path('comprobantes/', ComprobantesListado.as_view(template_name="comprobantes/index.html"), name='leer'),
    path('comprobantes/detalle/<int:pk>', ComprobantesDetalle.as_view(template_name="comprobantes/detalles.html"),
         name='detalles'),
    path('comprobantes/crear', ComprobantesCrear.as_view(template_name="comprobantes/crear.html"), name='crear'),
    path('comprobantes/editar/<int:pk>', ComprobantesActualizar.as_view(template_name="comprobantes/actualizar.html"),
         name='actualizar'),
    path('comprobantes/eliminar/<int:pk>', ComprobantesEliminar.as_view(), name='eliminar'),


]